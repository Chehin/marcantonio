<?php

namespace App\AppCustom\Models;

class ProductStatistic extends ModelCustomBase
{
    protected $table = 'inv_productos_estadisticas';
	
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded = [];
    
}
