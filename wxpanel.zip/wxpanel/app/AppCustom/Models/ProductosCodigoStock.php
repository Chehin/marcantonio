<?php

namespace App\AppCustom\Models;

class ProductosCodigoStock extends ModelCustomBase
{
    protected $table = 'inv_producto_codigo_stock';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
        
    protected $guarded = [];
    
}