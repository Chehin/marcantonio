<?php

namespace App\AppCustom\Models;

class Note extends ModelCustomBase
{
    protected $table = 'editorial_notas';
    
    
    protected $primaryKey = 'id_nota';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    //protected $fillable = ['id_edicion', 'id_seccion', 'titulo', 'sumario','texto','categoria','antetitulo','ciudad','pais','keyword','_url','orden'];
    
    protected $guarded = [];
    
    public $timestamps = false;
}
