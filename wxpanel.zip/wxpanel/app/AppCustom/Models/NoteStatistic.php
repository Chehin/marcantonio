<?php

namespace App\AppCustom\Models;

class NoteStatistic extends ModelCustomBase
{
    protected $table = 'editorial_notas_estadisticas';
	
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded = [];
    
}
