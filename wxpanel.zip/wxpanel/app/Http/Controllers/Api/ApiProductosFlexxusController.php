<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\AppCustom\Util;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\AppCustom\Models\ProductoFlexxus;
use App\AppCustom\Models\CodigoStock;
use App\AppCustom\Models\SucursalesStock;
use App\AppCustom\Models\Productos;
use App\AppCustom\Models\Rubros;
use App\AppCustom\Models\Marcas;
use App\AppCustom\Models\Genero;
use App\AppCustom\Models\Note;
use App\AppCustom\Models\Talles;
use App\AppCustom\Models\Colores;
use App\AppCustom\Models\PreciosProductos;

class ApiProductosFlexxusController extends Controller
{
    public function __construct(Request $request)
    {
        
        parent::__construct($request);
        
        $this->resource = 'productos';
        $this->resourceLabel = 'Productos';
        $this->modelName = 'App\AppCustom\Models\Productos';
    }

    public function store(Request $request){
        //Sucursales que maneja la tabla a importar
        $sucursales_array = array('STOCKTOTAL');

        $aResult = Util::getDefaultArrayResult();
        $error = array();

        if($this->user->hasAccess($this->resource . '.create')){

            $dat = $request->input('productos');
            $datos = json_decode($dat, true);

            foreach ($datos as $dato) {
                $codigoUnico = $dato['CODIGOARTICULO'].'-'.$dato['TALLE'];

                $codigoStock = CodigoStock::where('codigo','=',$codigoUnico)->first();

                if($codigoStock){
                
                    $stocktotal = 0;

                    foreach ($sucursales_array as $sucursal_array) {
                        \Log::info('----------------------------------------');
                        //Flexxus manda solo una
                        $stock = $dato[$sucursal_array];

                        $sucursal_aux = 'sucursal_web'; //Esta variable aux debe borrarse en el momento que manejen sucursales

                        //Si no existe la sucursal creo una
                        $sucursal = Note::select('id_nota', 'titulo')->where('id_edicion', \config('appCustom.MOD_SUCURSALES_FILTER'))->where('habilitado', 1)->where('antetitulo', $sucursal_aux)->first();
                        if(!$sucursal){
                            $sucursal = new Note();
                            $sucursal->id_edicion = \config('appCustom.MOD_SUCURSALES_FILTER');
                            $sucursal->titulo = $sucursal_array;
                            $sucursal->antetitulo = $sucursal_array;
                            $sucursal->save();
                            \Log::info('----NUEVA SUCURSAL !!----');
                            \Log::info($sucursal_array);
                        }
                        
                        //actualizo el stock de la sucursal
                        $stock_sucursal = SucursalesStock::where('id_codigo_stock', $codigoStock->id)->where('id_sucursal', $sucursal->id_nota)->first();

                        if(!$stock_sucursal){
                            $stock_sucursal = new SucursalesStock();
                            $stock_sucursal->id_codigo_stock = $codigoStock->id;
                            $stock_sucursal->id_sucursal = $sucursal->id_nota;
                        }
                        $stock_sucursal->stock = $stock;
                        $stock_sucursal->save();

                        \Log::info('----NUEVO POR STOCK SUCURSAL !!----');
                        \Log::info('codigo: '.$codigoStock->codigo. ' stock: ' .$stock_sucursal->stock. ' para sucursal: '. $sucursal->titulo);

                        $stocktotal += $stock;
                    }

                    //actualizo el stock total
                    $update=CodigoStock::where('id',$codigoStock->id)->update(['stock' => $stocktotal]);
                    \Log::info('----NUEVO STOCK TOTAL !!----');
                    \Log::info('codigo: '.$codigoStock->codigo. ' stock: ' .$stocktotal);

                    //ACTUALIZO PRECIO

                    if($codigoStock->id_producto){

                        // Verico si existe el producto 
                        $item = Productos::find($codigoStock->id_producto);

                        if (!$item) {
                            // Si no existe el producto se debe crear
                            // Array para crear un nuevo producto

                            //No sincroniza Productos

                            \Log::info('El Producto no existe');
                        }else{                       
                             // Se debe actualizar el producto

                            if($dato['LISTA1']){
                                $dato['LISTA1'] = round($dato['LISTA1'], 2, PHP_ROUND_HALF_UP);
                                // obtengo la moneda por default
                                $moneda_default = Util::getMonedaDefault();
                                $id_moneda = ($moneda_default?$moneda_default[0]['id']:1);

                                // Array para guardar el precio del producto
                                $array_precio = array(
                                    'resource_id' => $item->id,
                                    'id_moneda' => $id_moneda,
                                    'precio_venta' => $dato['LISTA1'],
                                    //'precio_lista' => $dato['LISTA1'],
                                    'descuento' => 0
                                );

                                // Obtengo el id del registro en la tabla inv_precios
                                $id_precio = PreciosProductos::select('id','precio_lista', 'descuento', 'precio_venta')
                                ->where('id_moneda','=',$id_moneda)
                                ->where('id_producto','=',$item->id)->first();

                                if ($id_precio) {

                                    //Si el precio es mayor se actualiza
                                    if($dato['LISTA1'] > $id_precio->precio_venta){
                                        $array_precio['precio_lista'] = $id_precio->precio_lista;
                                        $array_precio['descuento'] = $id_precio->descuento;
                                        $request->request->add($array_precio);
                                        $id = $id_precio->id;
                                        // Si tiene un precio cargado actualizo el valor
                                        $aResult = app('App\Http\Controllers\PreciosRelatedController')->update($request,$id);
                                        $aResult = json_decode($aResult->getContent(),true);
                                        \Log::info('----PRECIO ACTUALIZADO!!----');
                                        \Log::info($id_precio->precio_venta.'---'.$dato['LISTA1']);
                                    }else{
                                        \Log::info('El precio es menor al precio WEB');
                                        $aResult = array();
                                        $aResult['status'] = 200;
                                        $aResult['msg'] = array('Precio No Actualizado. El precio es menor al precio WEB');
                                    }
                                } else {
                                    $request->request->add($array_precio);
                                    // Si no tiene un precio cargado lo creo
                                    $aResult = app('App\Http\Controllers\PreciosRelatedController')->store($request);
                                    $aResult = json_decode($aResult->getContent(),true);
                                    \Log::info('----PRECIO NUEVO!!----');
                                    \Log::info($dato['LISTA1']);
                                }

                                if ($aResult['status'] == 1) {
                                    array_push($error, 'El precio del producto' . $item->nombre . ', id: ' . $item->id . ' no se pudo actualizar ('.$aResult['msg'][0].')');
                                }                                

                            }else{
                                // obtengo la moneda por default
                                $moneda_default = Util::getMonedaDefault();
                                $id_moneda = ($moneda_default?$moneda_default[0]['id']:1);
                                // Elimino los precios cargados para este producto
                                $id_precio = PreciosProductos::
                                where('id_moneda','=',$id_moneda)
                                ->where('id_producto','=',$item->id)->delete();
                                \Log::info('----BORRAR PRECIO!!----');
                                \Log::info('Flexxus No Envio precio');
                            }
                        }
                    }else{
                        \Log::info('El stock fue encontrado pero No tiene Producto Asociado');
                    }
                }else{
                    Log::info('stock no encontrado');
                }
                
                \Log::info('----------------------------------------');
            }

        } else {
            $aResult['status'] = 1;
            $aResult['msg'] = \config('appCustom.messages.unauthorized');
        }
        if($error){
            \Log::error($error);
        }
        $aResult['data'] = $error;
        //\Log::info('Sincronizado con flexxus');
        //return response()->json($aResult);
    }
}
