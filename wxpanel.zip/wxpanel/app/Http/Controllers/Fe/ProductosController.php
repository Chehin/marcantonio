<?php

namespace App\Http\Controllers\fe;

use Illuminate\Http\Request;
use App\AppCustom\Util;
use Illuminate\Pagination\Paginator;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Fe\FeUtilController;
use App\AppCustom\Models\Productos;
use App\AppCustom\Models\Rubros;
use App\AppCustom\Models\SubRubros;
use App\AppCustom\Models\CodigoStock;
use App\AppCustom\Models\SubSubRubros;
use App\AppCustom\Models\Etiquetas;
use App\AppCustom\Models\EtiquetasRubros;
use App\AppCustom\Models\ProductosEtiquetas;
use App\AppCustom\Models\ProductosDeportes;
use App\AppCustom\Models\Deportes;
use App\AppCustom\Models\ProductStatistic;
use App\AppCustom\Models\Marcas;
use App\AppCustom\Models\Pais;
use App\AppCustom\Models\Genero;
use Carbon\Carbon;

class ProductosController extends Controller
{
	public function __construct(Request $request)
    {
		parent::__construct($request);
		
        $this->resource = $request->input('edicion');
		$this->filterNote = \config('appCustom.'.$request->input('id_edicion'));
		
		$this->fotos = ($request->input('fotos')?$request->input('fotos'):'all');		
		$this->orden = $request->input('orden');
		$this->iDisplayLength = $request->input('iDisplayLength');
		$this->iDisplayStart = $request->input('iDisplayStart');
		$this->limit = $request->input('limit');
		$this->id_relacion = $request->input('id_relacion');
		$this->forzar = $request->input('forzar');
		$this->id_moneda = $request->input('id_moneda');
		$this->filtros = $request->input('filtros');
		$this->tag = $request->input('tag');
		$this->id_deporte = $request->input('id_deporte');
		$this->search = $request->input('search');
		$this->id_marca = $request->input('id_marca');
		$this->mas_vistos = $request->input('mas_vistos');
		$this->idProducto = $request->input('idProducto');
    }
	public function rubros(Request $request)
    {
        $aResult = Util::getDefaultArrayResult();        
		
        if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$rubros = Util::getRubros('array', true);
			foreach($rubros as $rubro){
				$subrubros = Util::getSubRubros($rubro['id'],'array', true);
				$array_subrubro = array();
				foreach($subrubros as $subrubro){
					$data1 = array(
						'id' => $subrubro['id'],
						'text' => $subrubro['text'],
						'cantidad' => $subrubro['cantidad'],
						'subsubrubros' => Util::getSubSubRubros($subrubro['id'],'array', true)
					);
					array_push($array_subrubro,$data1);
				}
				$data = array(
					'id' => $rubro['id'],
					'text' => $rubro['text'],
					'cantidad' => $rubro['cantidad'],
					'subrubros' => $array_subrubro
				);
				array_push($aResult['data'],$data);
			}
        } else {
            $aResult['status'] = 1;
            $aResult['msg'] = \config('appCustom.messages.unauthorized');
        }
        return response()->json($aResult);
    }
	public function listado(Request $request)
    {
        $aResult = Util::getDefaultArrayResult();
        if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$aResult['data']['productos'] = array();
			$aResult['data']['total'] = array();
			$pageSize = $this->iDisplayLength;
            $offset = $this->iDisplayStart;
            $limit = $this->limit;
            $currentPage = ($offset / $pageSize) + 1;
			$sort = $this->orden;
			$rand = false;
			if($sort=='rand'){
				$rand = true;
			}else{
				$sortDir = $sort['dir'];
				$sortCol = $sort['col'];
			}
			Paginator::currentPageResolver(function() use ($currentPage) {
                return $currentPage;
            });
			$etiqueta_array = array();
			$aResult['data']['etiqueta'] = null;
			if($this->tag || isset($this->id_deporte)){
				$etiqueta = Etiquetas::find($this->tag);
				if($etiqueta){
					//foto header etiqueta
					$aOItemsEtiqueta = FeUtilController::getImages($this->tag,1, 'etiquetas');

					$etiqueta_array['id'] = $etiqueta->id;
					$etiqueta_array['nombre'] = $etiqueta->nombre;
					$etiqueta_array['header'] = $aOItemsEtiqueta;
					$aResult['data']['etiqueta'] = $etiqueta_array;
				}
				if($this->tag && $this->id_deporte){
					$aItems = ProductosEtiquetas::
					select('inv_productos.id', 'inv_productos.nombre', 'inv_productos.id_rubro', 'inv_productos.id_subrubro', 'inv_productos.id_subsubrubro')
					->leftJoin('inv_productos','inv_productos.id','=','inv_productos_etiquetas.id_producto')
					->leftJoin('inv_productos_deportes','inv_productos_deportes.id_producto','=','inv_productos.id')
					->where('inv_productos.habilitado',1)
					->where('inv_productos_etiquetas.id_etiqueta',$this->tag)
					->where('inv_productos_deportes.id_deporte',$this->id_deporte);
				}elseif($this->tag){
					$aItems = ProductosEtiquetas::
					select('inv_productos.id', 'inv_productos.nombre', 'inv_productos.id_rubro', 'inv_productos.id_subrubro', 'inv_productos.id_subsubrubro')
					->leftJoin('inv_productos','inv_productos.id','=','inv_productos_etiquetas.id_producto')
					->where('inv_productos.habilitado',1)
					->where('inv_productos_etiquetas.id_etiqueta',$this->tag);
				}else{
					$aItems = ProductosDeportes::
					select('inv_productos.id', 'inv_productos.nombre', 'inv_productos.id_rubro', 'inv_productos.id_subrubro', 'inv_productos.id_subsubrubro')
					->leftJoin('inv_productos','inv_productos.id','=','inv_productos_deportes.id_producto')
					->where('inv_productos.habilitado',1)
					->where('inv_productos_deportes.id_deporte',$this->id_deporte);
				}
			}elseif($this->mas_vistos){
				$aItems = ProductStatistic::
				select('inv_productos.id', 'inv_productos.nombre', 'inv_productos.id_rubro', 'inv_productos.id_subrubro', 'inv_productos.id_subsubrubro')
				->leftJoin('inv_productos','inv_productos.id','=','inv_productos_estadisticas.id_producto')
				->where('inv_productos.habilitado',1)
				->orderBy('inv_productos_estadisticas.visitas','desc');
			}elseif($this->search){
				$search = $this->search;
				$sortCol = 'inv_productos.orden';
				$aItems = CodigoStock::
				select('inv_productos.id', 'inv_productos.nombre', 'inv_productos.id_rubro', 'inv_productos.id_subrubro', 'inv_productos.id_subsubrubro')
				->leftJoin('inv_productos','inv_productos.id','=','inv_producto_codigo_stock.id_producto')		
				->leftJoin('inv_rubros','inv_rubros.id','=','inv_productos.id_rubro')
				->leftJoin('conf_marcas','conf_marcas.id','=','inv_productos.id_marca')
				->where('inv_productos.habilitado',1)
				->where(function($query) use ($search){
					$query
					->where('inv_productos.nombre','like',"%{$search}%")
					->orWhere('inv_productos.sumario','like',"%{$search}%")
					->orWhere('inv_productos.texto','like',"%{$search}%")
					->orWhere('inv_producto_codigo_stock.codigo','like',"%{$search}%")
					->orWhere('conf_marcas.nombre','like',"%{$search}%")
					->orWhere('inv_rubros.nombre','like',"%{$search}%");
				})
				->groupBy('inv_productos.id');			
			}else{
				$aItems = Productos::
				select('id', 'nombre', 'id_rubro', 'id_subrubro', 'id_subsubrubro')
				->where('habilitado', 1);
			}
			if ($this->idProducto) {
				$aItems->where('inv_productos.id', $this->idProducto);
			}
			
			if($this->filtros){
				$filtros = $this->filtros;
				foreach($filtros as $clave => $valor){
					$clave = "inv_productos.$clave";
					$aItems = $aItems->where($clave,$valor);
				}
			}
			
			if($this->id_marca){
				$aItems = $aItems->where('inv_productos.id_marca',$this->id_marca);
			}
			if($limit){
				$aItems = $aItems->limit($limit);
			}
			if($rand){
				$aItems = $aItems->inRandomOrder();
			}else{
				$aItems = $aItems->orderBy($sortCol, $sortDir);
				$aItems = $aItems->orderBy('inv_productos.id', $sortDir);
			}
			$aItems = $aItems->paginate($pageSize);
			
			//categorias
			$aResult['data']['categoria'] = array();
			if(isset($filtros['id_rubro']) || isset($filtros['id_subrubro'])){
				if(!isset($filtros['id_rubro'])){
					$getsubrubro = SubRubros::find($filtros['id_subrubro']);
					$filtros['id_rubro'] = $getsubrubro->id_rubro;
				}
				$rubro = Rubros::find($filtros['id_rubro']);
				if($rubro){
					$aOItemsRubros = FeUtilController::getImages($rubro->id,1, 'rubros');
					$aResult['data']['categoria']['rubro'] = array(
						'id' => $rubro->id,
						'rubro' => $rubro->nombre,
						'header' => $aOItemsRubros
					);
				}
			}
			if(isset($filtros['id_subrubro'])){
				$subrubro = SubRubros::find($filtros['id_subrubro']);
				if($subrubro){
					$aResult['data']['categoria']['subrubro'] = array(
						'id' => $subrubro->id,
						'subrubro' => $subrubro->nombre,
					);
				}
			}
			if(isset($filtros['id_subsubrubro'])){
				$subsubrubro = SubSubRubros::find($filtros['id_subsubrubro']);
				if($subsubrubro){
					$aResult['data']['categoria']['subsubrubro'] = array(
						'id' => $subrubro->id,
						'subsubrubro' => $subsubrubro->nombre
					);
				}
			}
			if(isset($filtros['id_genero'])){
				$genero = Genero::find($filtros['id_genero']);
				if($genero){
					$aResult['data']['genero'] = array(
						'id' => $genero->id,
						'genero' => $genero->genero
					);
				}
			}else{
				$aResult['data']['genero'] = array();
			}
			
			$coloresStock = array();
			foreach ($aItems as $item) {
				if($this->fotos){
					$aOItems = FeUtilController::getImages($item->id,$this->fotos, $this->resource);
					if($aOItems){
						array_walk($aOItems, function(&$val,$key)use($item){
							$coloresStock = FeUtilController::getStockColor($item->id, $val['id_color']);
							$val['stock'] = isset($coloresStock[0]['stock'])?$coloresStock[0]['stock']:0;
							$val['id_talle'] = isset($coloresStock[0]['id_talle'])?$coloresStock[0]['id_talle']:0;
						});
					}else{
						$coloresStock = FeUtilController::getStockColor($item->id, 0);
						$aOItems[0]['stock'] = isset($coloresStock[0]['stock'])?$coloresStock[0]['stock']:0;
						$aOItems[0]['id_talle'] = isset($coloresStock[0]['id_talle'])?$coloresStock[0]['id_talle']:0;
						$aOItems[0]['id_color'] = 0;
					}
				}else{
					$aOItems = '';
				}
				//precio
				$precio = FeUtilController::getPrecios($item->id,$this->id_moneda);
				
				$fecha = Carbon::parse($item->updated_at)->format('d/m/Y');
				//rubro y subrubro
				$rubro = array(
					'id' => $item->id_rubro,
					'rubro' => Rubros::find($item->id_rubro)->nombre
				);
				$subrubro = array();
				if($item->id_subrubro){
					$subrubro = array(
						'id' => $item->id_subrubro,
						'subrubro' => SubRubros::find($item->id_subrubro)->nombre
					);
				}
				if($item->id_subsubrubro){
					$subsubrubro = array(
						'id' => $item->id_subsubrubro,
						'subsubrubro' => SubSubRubros::find($item->id_subsubrubro)->nombre
					);
				}
				$data = array(
					'id' => $item->id,
					'titulo' => $item->nombre,
					'sumario' => $item->sumario,
					'categoria' => array(
						'rubro' => $rubro,
						'subrubro' => $subrubro,
						'subsubrubro' => isset($subsubrubro)?$subsubrubro:''
					),
					'fotos' => $aOItems,
					'precios' => $precio,
					'updated_at' => $fecha
				);
				array_push($aResult['data']['productos'],$data);
			}
			$aResult['data']['total'] = $aItems->total();
		}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}
		return response()->json($aResult);
	}

	public function producto(Request $request)
    {
        $aResult = Util::getDefaultArrayResult();
		
        if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$id = $request->input('id');
		
            $aItems = Productos::
			where('habilitado',1)
			->where('id', $id)
			->first();			
			if($aItems){
				$coloresStock = FeUtilController::getColorTalles($aItems->id);
				$aOItems = array();
				//imagenes
				if($coloresStock){
					$aOItems = FeUtilController::getImagesByColor($aItems->id, 99, $this->resource, $coloresStock[0]['id_color']);
				}else{
					$coloresStock = array();
					$coloresStock[0] = array(
						'codigo' => '',
						'id_color' => 0
					);
				}

				//rubro y subrubro
				$rubro = array(
					'id' => $aItems->id_rubro,
					'rubro' => Rubros::find($aItems->id_rubro)->nombre
				);
				$subrubro = array();
				if($aItems->id_subrubro){
					$subrubro = array(
						'id' => $aItems->id_subrubro,
						'subrubro' => SubRubros::find($aItems->id_subrubro)->nombre
					);
				}
				if($aItems->id_subsubrubro){
					$subsubrubro = array(
						'id' => $aItems->id_subsubrubro,
						'subsubrubro' => SubSubRubros::find($aItems->id_subsubrubro)->nombre
					);
				}else{
					$subsubrubro = array();
				}
				
				//precio
				$precio = FeUtilController::getPrecios($aItems->id,$this->id_moneda);
				
				//marca
				$marca = Marcas::find($aItems->id_marca);
				$aItems->marca = ($marca?$marca->nombre:'');
				
				//origen
				$origen = Pais::find($aItems->id_origen);
				$aItems->origen = ($origen?$origen->pais:'');

				//genero
				$genero = Genero::find($aItems->id_genero);
				$aItems->genero = ($genero?$genero->genero:'');

				//registro visita al producto
				FeUtilController::newVisitorProduct($aItems->id, $aItems->nombre);
				
				$data = array(
					'producto' => $aItems,
					'categoria' => array(
						'rubro' => $rubro,
						'subrubro' => $subrubro,
						'subsubrubro' => $subsubrubro
					),
					'precios' => $precio,
					'stockColor' => $coloresStock,
					'fotos' => $aOItems
				);
				$aResult['data'] = $data;
			}else{
				$aResult['status'] = 1;
				$aResult['msg'] = 'Producto no encontrado';
			}
        } else {
			$aResult['status'] = 1;
				$aResult['msg'] = \config('appCustom.messages.unauthorized');
			}
        return response()->json($aResult);
    }
	public function relacionados(Request $request)
    {
        $aResult = Util::getDefaultArrayResult();
		
        if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$aResult['data']['productos_rel'] = array();
			$aResult['data']['mas_productos'] = array();
			$aResult['data']['total_rel'] = array();
			$aResult['data']['total_mas'] = array();
			$pageSize = $this->iDisplayLength;
            $offset = $this->iDisplayStart;
            $limit = $this->limit;
            $currentPage = ($offset / $pageSize) + 1;
			$sort = $this->orden;
			$rand = false;
			if($sort=='rand'){
				$rand = true;
			}else{
				$sortDir = $sort['dir'];
				$sortCol = $sort['col'];
			}
			Paginator::currentPageResolver(function() use ($currentPage) {
                return $currentPage;
            });
			
			$aItems = Productos::
			select('id', 'nombre', 'id_rubro', 'id_subrubro')
			->join("inv_productos_relacion as a","a.id_secundaria","=","inv_productos.id")
			->where("a.id_principal", $this->id_relacion)
			->where('habilitado', 1);
			if($this->filtros){
				$filtros = $this->filtros;
				$id_relacion = $filtros['id_relacion'];
				$aItems = $aItems->where('id','!=',$id_relacion);
			}
			if($rand){
				$aItems = $aItems->inRandomOrder();
			}else{
				$aItems = $aItems->orderBy($sortCol, $sortDir);
			}
			$aItems = $aItems->paginate($pageSize);
			foreach ($aItems as $item) {
				if($this->fotos){
					$aOItems = FeUtilController::getImages($item->id,$this->fotos, $this->resource);
					if($aOItems){
						array_walk($aOItems, function(&$val,$key)use($item){
							$coloresStock = FeUtilController::getStockColor($item->id, $val['id_color']);
							$val['stock'] = isset($coloresStock[0]['stock'])?$coloresStock[0]['stock']:0;
							$val['id_talle'] = isset($coloresStock[0]['id_talle'])?$coloresStock[0]['id_talle']:0;
						});
					}else{
						$coloresStock = FeUtilController::getStockColor($item->id, 0);
						$aOItems[0]['stock'] = isset($coloresStock[0]['stock'])?$coloresStock[0]['stock']:0;
						$aOItems[0]['id_talle'] = isset($coloresStock[0]['id_talle'])?$coloresStock[0]['id_talle']:0;
						$aOItems[0]['id_color'] = 0;
					}
				}else{
					$aOItems = '';
				}
				//precio
				$precio = FeUtilController::getPrecios($item->id,$this->id_moneda);
				
				$fecha = Carbon::parse($item->updated_at)->format('d/m/Y');
				//rubro y subrubro
				$rubro = array(
					'id' => $item->id_rubro,
					'rubro' => Rubros::find($item->id_rubro)->nombre
				);
				$subrubro = array();
				if($item->id_subrubro){
					$subrubro = array(
						'id' => $item->id_subrubro,
						'subrubro' => SubRubros::find($item->id_subrubro)->nombre
					);
				}
				$data = array(
					'id' => $item->id,
					'titulo' => $item->nombre,
					'sumario' => $item->sumario,
					'categoria' => array(
						'rubro' => $rubro,
						'subrubro' => $subrubro
					),
					'fotos' => $aOItems,
					'precios' => $precio,
					'updated_at' => $fecha
				);
				array_push($aResult['data']['productos_rel'],$data);
			}
			$aResult['data']['total_rel'] = $aItems->total();
			
			// *********************************************************************
			//obtengo los productos del mismo rubro					
			
			$aItems = Productos::
			select('id', 'nombre', 'id_rubro', 'id_subrubro')
			->where('habilitado', 1);
			if($this->filtros){
				$filtros = $this->filtros;
				$id_relacion = $filtros['id_relacion'];
				$aItems = $aItems->where('id_rubro',Productos::find($id_relacion)->id_rubro)->where('id','!=',$id_relacion);
			}
			if($limit){
				$aItems = $aItems->limit($limit);
			}
			if($rand){
				$aItems = $aItems->inRandomOrder();
			}else{
				$aItems = $aItems->orderBy($sortCol, $sortDir);
			}
			$aItems = $aItems->paginate($limit);
			foreach ($aItems as $item) {
				if($this->fotos){
					$aOItems = FeUtilController::getImages($item->id,$this->fotos, $this->resource);
					if($aOItems){
						array_walk($aOItems, function(&$val,$key)use($item){
							$coloresStock = FeUtilController::getStockColor($item->id, $val['id_color']);
							$val['stock'] = isset($coloresStock[0]['stock'])?$coloresStock[0]['stock']:0;
							$val['id_talle'] = isset($coloresStock[0]['id_talle'])?$coloresStock[0]['id_talle']:0;
						});
					}else{
						$coloresStock = FeUtilController::getStockColor($item->id, 0);
						$aOItems[0]['stock'] = isset($coloresStock[0]['stock'])?$coloresStock[0]['stock']:0;
						$aOItems[0]['id_talle'] = isset($coloresStock[0]['id_talle'])?$coloresStock[0]['id_talle']:0;
						$aOItems[0]['id_color'] = 0;
					}
				}else{
					$aOItems = '';
				}
				//precio
				$precio = FeUtilController::getPrecios($item->id,$this->id_moneda);
				
				$fecha = Carbon::parse($item->updated_at)->format('d/m/Y');
				//rubro y subrubro
				$rubro = array(
					'id' => $item->id_rubro,
					'rubro' => Rubros::find($item->id_rubro)->nombre
				);
				$subrubro = array();
				if($item->id_subrubro){
					$subrubro = array(
						'id' => $item->id_subrubro,
						'subrubro' => SubRubros::find($item->id_subrubro)->nombre
					);
				}
				
				$data = array(
					'id' => $item->id,
					'titulo' => $item->nombre,
					'sumario' => $item->sumario,
					'categoria' => array(
						'rubro' => $rubro,
						'subrubro' => $subrubro
					),
					'fotos' => $aOItems,
					'precios' => $precio,
					'updated_at' => $fecha
				);
				array_push($aResult['data']['mas_productos'],$data);
			}
			$aResult['data']['total_mas'] = $aItems->total();
		}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}
		return response()->json($aResult);
	}

	public function etiquetasMenu(Request $request)
	{
		$aResult = Util::getDefaultArrayResult();
		
        if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$etiquetas = Etiquetas::select('id','nombre')
			->where('habilitado',1)->where('menu',1)
			->orderBy('orden','asc')
			->get();
			$aResult['data'] = $etiquetas;
			return response()->json($aResult);
		}
	}

	public function menu(Request $request)
	{
		$data = array();

		$generos = Productos::select('conf_generos.id', 'conf_generos.genero', 'conf_generos.alias')
		->leftJoin('conf_generos','conf_generos.id','=','inv_productos.id_genero')
		->where('inv_productos.habilitado',1)
		->orderBy('conf_generos.orden')
		->orderBy('conf_generos.alias')
		->orderBy('conf_generos.genero')
		->groupBy('inv_productos.id_genero')
		->get()->toArray();
		array_walk($generos, function(&$val,$key){
			$rubros = Productos::select('inv_rubros.id', 'inv_rubros.nombre', \DB::raw('COUNT(inv_rubros.id) as cantidad'))
			->leftJoin('inv_rubros','inv_rubros.id','=','inv_productos.id_rubro')
			->where('inv_productos.habilitado',1)
			->where('inv_productos.id_genero',$val['id'])
			->orderBy('inv_rubros.nombre')
			->groupBy('inv_productos.id_rubro')
			->get()->toArray();
			array_walk($rubros, function(&$val1,$key1)use($val){
				$subrubros = Productos::
				select('inv_subrubros.id', 'inv_subrubros.nombre', \DB::raw('COUNT(inv_subrubros.id) as cantidad'))
				->leftJoin('inv_subrubros','inv_subrubros.id','=','inv_productos.id_subrubro')
				->where('inv_productos.habilitado',1)
				->where('inv_productos.id_rubro',$val1['id'])
				->where('inv_productos.id_genero',$val['id'])
				->orderBy('inv_subrubros.nombre')
				->groupBy('inv_productos.id_subrubro')
				->get()->toArray();
				if($subrubros){
					$val1['subrubros'] = $subrubros;
				}else{
				}
			});
			if($rubros){
				$val['rubros'] = $rubros;
			}
		});
		if($generos){
			$data['generos'] = $generos;
		}

		//deportes
		$deportes = Deportes::select('id','nombre')->where('habilitado',1)->where('menu', 1)->get()->toArray();
		if($deportes){
			$data['deportes'] = $deportes;
		}
		//marcas
		$marcas = Marcas::select('id','nombre')->where('habilitado',1)->where('destacado', 1)->get()->toArray();
		if($marcas){
			$data['marcas'] = $marcas;
		}

		$etiquetas = Etiquetas::select('id','nombre')
		->where('habilitado',1)->where('menu',1)
		->orderBy('orden','asc')
		->get();
		$data['etiquetas'] = $etiquetas;

		$aResult['data'] = $data;
		return response()->json($aResult);
	}

	public function cambiarColor(Request $request){
		$aResult = Util::getDefaultArrayResult();

		$id = $request->input('id_producto');
		$id_color = $request->input('id_color');

		//taer fotos, [talles, codigos y stock]
		$coloresStock = FeUtilController::getColorTalles($id, $id_color);
		$aOItems = FeUtilController::getImagesByColor($id, 'all', $this->resource, $id_color);
		$aResult['data'] = array(
			'fotos' => $aOItems,
			'talles' => $coloresStock
		);
		return response()->json($aResult);
	}
	public function filtros(Request $request){
		$aResult = Util::getDefaultArrayResult();        
		$marcas = array();
        if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$rubros = $this->rubros($request);
			$aResult['data']['rubros'] = json_decode(json_encode($rubros->getData()),true);

			$marcas = Util::getMarcas('array', true);
			$aResult['data']['marcas'] = $marcas;

			$etiquetas = Util::getEtiquetas('array');
			$aResult['data']['etiquetas'] = $etiquetas;
		}else{
			$aResult['status'] = 1;
            $aResult['msg'] = \config('appCustom.messages.unauthorized');
		}
		return response()->json($aResult);
	}
	public function search(Request $request)
    {
        $aResult = Util::getDefaultArrayResult();
		
        if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$array_send = array(
				"fotos" => 1,
				"id_moneda" => 1,
				"orden" => array(
					"col" => "inv_productos.orden",
					"dir" => "ASC"
				),
				"iDisplayLength" => 10,
				"iDisplayStart" => 0,
				"search" => $this->search
			);
			$request->request->add($array_send);
			$aResult = app('App\Http\Controllers\Fe\ProductosController')->listado($request);
			$aResult = json_decode($aResult->getContent(),true);

		}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}
		return response()->json($aResult);
	}
}