<?php
	
namespace App\Http\Controllers\fe;

use Illuminate\Http\Request;
use App\AppCustom\Util;
use App\AppCustom\Cart;
use Illuminate\Pagination\Paginator;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Fe\FeUtilController;
use Carbon\Carbon;
use App\AppCustom\Models\TipoEnvio;
use App\AppCustom\Models\PedidosDirecciones;
use App\AppCustom\Models\PedidosClientes;
use App\AppCustom\Models\Pedidos;
use App\AppCustom\Models\Provincias;
use App\AppCustom\Models\Productos;
use App\AppCustom\Models\PreciosProductos;
use App\AppCustom\Models\PedidosProductos;
use App\AppCustom\Models\Note;
use App\AppCustom\Models\SucursalesStock;
use Andreani\Andreani;
use Andreani\Requests\CotizarEnvio;
use MP;
use TodoPago\Sdk;

class EnvioController extends Controller
{
	public function __construct(Request $request)
	{
		parent::__construct($request);
		
		$this->resource = $request->input('edicion');
		$this->filterNote = \config('appCustom.'.$request->input('id_edicion'));
		$this->id_idioma = $request->input('idioma');
		
		$this->id_usuario = $request->input('id_usuario');
		$this->cookie = $request->input('cookie');
		$this->item = $request->input('item');
	}
	public function getDistancia($lat1, $long1, $lat2, $long2){ 
		//Distancia en kilometros en 1 grado distancia.
		//Distancia en millas nauticas en 1 grado distancia: $mn = 60.098;
		//Distancia en millas en 1 grado distancia: 69.174;
		//Solo aplicable a la tierra, es decir es una constante que cambiaria en la luna, marte... etc.
		$km = 111.302;
		
		//1 Grado = 0.01745329 Radianes    
		$degtorad = 0.01745329;
		
		//1 Radian = 57.29577951 Grados
		$radtodeg = 57.29577951; 
		//La formula que calcula la distancia en grados en una esfera, llamada formula de Harvestine. Para mas informacion hay que mirar en Wikipedia
		//http://es.wikipedia.org/wiki/F%C3%B3rmula_del_Haversine
		$dlong = ($long1 - $long2); 
		$dvalue = (sin($lat1 * $degtorad) * sin($lat2 * $degtorad)) + (cos($lat1 * $degtorad) * cos($lat2 * $degtorad) * cos($dlong * $degtorad)); 
		$dd = acos($dvalue) * $radtodeg; 
		return round(($dd * $km), 2);
	}
	
	public function getDireccionEnvio(Request $request){
		$aResult = Util::getDefaultArrayResult();
		if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$id_usuario = $request->input('id_usuario');
			$direccion_envio = PedidosDirecciones::select(\DB::raw('CONCAT(direccion, " ", numero) as direccion'),'id')->where('id_usuario','=',$id_usuario)->lists('direccion', 'id');
			$aResult['data'] = $direccion_envio;
			}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}	
		return response()->json($aResult);
	}

	public function getTipoEnvio(Request $request){
		$aResult = Util::getDefaultArrayResult();
		
		//tipos de envios
		$delivery_propio = false;
		$mercado_envio = true;
		$andreani = true;
		$envio_acordar = false;
		/////////////

		$respuesta = array();
		$prod_oferta = false;
		$id = $request->input('id'); // ID dirección seleccionada por el cliente
		$pedidos = $request->input('pedido'); // los datos del pedidos, productos a comprar
		$subtotal = $request->input('subtotal'); // el costo de la operación
		if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$cp = PedidosDirecciones::find($id); // Obtengo los datos de la dirección 			
			$alto = $ancho = $largo = $peso = 0;
			foreach ($pedidos as $pedido) {
				$item = Productos::find($pedido['id_producto']);
				$alto = $alto + ($item->alto*$pedido['cantidad']);
				$ancho = $ancho + ($item->ancho*$pedido['cantidad']);
				$largo = $largo + ($item->largo*$pedido['cantidad']);
				$peso = $peso + ($item->peso*$pedido['cantidad']);
				if($item->oferta == 1){
					$prod_oferta = true;
				}
				if($item->alto == 0 || $item->ancho == 0 || $item->largo == 0 || $item->peso == 0){
					$mercado_envio = false;
					$andreani = false;
				}
			}
			if($alto > 70 || $ancho > 70 || $largo > 70 || $peso > 25000){
				//$mercado_envio = false;
				$alto = $ancho = $largo = 70;
				$peso = 25000;
			}			
			if($delivery_propio){
				$prov = Provincias::find($cp->id_provincia);
				//delivery marcantonio
				$map_address = $cp->direccion. ' '.$cp->numero.' '.$cp->ciudad.' '.$prov->provincia.' Argentina';
				$url = "https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyDPGUWUeNkS7HfMXZO33taHOci4nYrsYXQ&sensor=false&address=".urlencode($map_address);
				$lat_long = get_object_vars(json_decode(file_get_contents($url)));
				
				//latitud y longitud sucursal marcantonio
				$lat1 = '-26.829728';
				$long1 = '-65.2335332';
				if(isset($lat_long['results'][0]->geometry->location->lat) && isset($lat_long['results'][0]->geometry->location->lng)){
					$lat2 = $lat_long['results'][0]->geometry->location->lat;
					$long2 = $lat_long['results'][0]->geometry->location->lng;
					
					$distancia = $this->getDistancia($lat1, $long1, $lat2, $long2);
					if($distancia<=20){
						$envioGratis = FeUtilController::getPrecioEnvioGratis();
						if(($envioGratis!=null && $envioGratis>=0 && $subtotal>=$envioGratis) || $prod_oferta){
							$cost = 0;
						}else{
							$cost = 250;
						}
						$data = array(
							'id' => -1,
							'name' => 'Delivery a domicilio Marcantonio Deportes - $'.$cost,
							'id_tipo_envio' => -1,
							'cost' => $cost,
							'total' => Util::getPrecioFormat($subtotal),
							'empresa' => 'Marcantonio'
						);
						array_push($respuesta,$data);
					}
					
				}
			}
			if($mercado_envio){
				$tamano_paquete = $alto."x".$ancho."x".$largo.",".$peso;
				// Verfico que el articulo no supere las medidas estandar para Mercado Envíos
				$params = array(
					"dimensions" => $tamano_paquete,
					"zip_code" => $cp->cp,
					"item_price"=>$subtotal
				);
				$response = MP::get('/shipping_options',$params);
				if($response){
					$shipping_options = $response['response']['options'];
					foreach($shipping_options as $shipping_option) {
						$shipping_method_id = $shipping_option['shipping_method_id'];
						$name = $shipping_option['name'];
						$shipping_speed = $shipping_option['estimated_delivery_time']['shipping'];
						$estimated_delivery = $shipping_speed < 24 ? (1).' dia' : ceil($shipping_speed / 24).' d&iacute;as'; //from departure, estimated delivery time
						$cost = $shipping_option['cost'];
						$tipo = TipoEnvio::select('id_tipo_envio','id_tipo')->where('id_tipo',$shipping_method_id)->first();
						if($tipo){
							$id_tipo_envio = $tipo->id_tipo_envio;
							$codigo_tipo_envio = $tipo->id_tipo;
						}else{
							$tipo_envio = new TipoEnvio;
							$tipo_envio->id_tipo = $shipping_method_id;
							$tipo_envio->nombre = $name;
							$tipo_envio->empresa = 'MercadoE';
							$tipo_envio->save();
							$id_tipo_envio = $tipo_envio->id_tipo_envio;
							$codigo_tipo_envio = $tipo->id_tipo;
						}
						$data = array(
							'id' => $shipping_method_id,
							'name' => $name.' - Mercado Envíos - $'.$cost,
							'id_tipo_envio' => $id_tipo_envio,
							'tipo_envio' => $codigo_tipo_envio,
							'cost' => $cost,
							'total' => Util::getPrecioFormat($subtotal),
							'empresa' => 'Mercado Envíos'
						);
						array_push($respuesta,$data);
					}
				}
			}
			if($andreani){
				// Calculos de precios de envios para Andreani
				$andreani_datos = array(
					'cliente'	=> \config('appCustom.ANDREANI_CLIENTE'), 
					'usuario' 	=> \config('appCustom.ANDREANI_USUARIO'),
					'pass' 		=> \config('appCustom.ANDREANI_PASS'),
					'ambiente' 	=> \config('appCustom.ANDREANI_AMBIENTE')
				);
				$volumen = $alto*$ancho*$largo;
				$tipo_envio = TipoEnvio::select('id_tipo_envio','id_tipo','nombre')->where('empresa','=','Andreani')->get();

				if ($tipo_envio) {
					foreach ($tipo_envio as $tipo) {
						// Los siguientes datos son de prueba, para la implementación en un entorno productivo deberán reemplazarse por los verdaderos					    
						$cotizar = new CotizarEnvio();
						$cotizar->setCodigoDeCliente($andreani_datos['cliente']);
						$cotizar->setNumeroDeContrato($tipo->id_tipo);
						$cotizar->setCodigoPostal($cp->cp);
						$cotizar->setPeso($peso);
						$cotizar->setVolumen($volumen);
						$cotizar->setValorDeclarado($subtotal);

						$andreani = new Andreani($andreani_datos['usuario'],$andreani_datos['pass'],$andreani_datos['ambiente']);
						$response = $andreani->call($cotizar);
						if($response->isValid()){
							$mensaje = $response->getMessage();
							$data = array(
								'id' => $tipo->id_tipo,
								'name' => $tipo->nombre.' - $'.$mensaje->CotizarEnvioResult->Tarifa,
								'id_tipo_envio' => $tipo->id_tipo_envio,
								'tipo_envio' => $tipo->id_tipo,
								'cost' => $mensaje->CotizarEnvioResult->Tarifa,
								'total' => Util::getPrecioFormat($subtotal),
								'respuesta' => $mensaje,
								'empresa' => 'Andreani'
							);
							array_push($respuesta,$data);
						}
					}
				}
			}
			if(count($respuesta)==0){
				if($envio_acordar){
					$data = array(
						'id' => -2,
						'name' => 'Entrega a acordar con Marcantonio Deportes',
						'total' => Util::getPrecioFormat($subtotal),
						'empresa' => 'Marcantonio'
					);
					array_push($respuesta,$data);
				}else{
					$data = array(
						'id' => 0,
						'name' => 'No hay formas de envio disponibles para su direccion',
						'empresa' => 'Marcantonio'
					);
					array_push($respuesta,$data);
				}
			}
			$aResult['data'] = $respuesta;
		}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}	
		return response()->json($aResult);
	}

	public function setTipoEnvio(Request $request)
	{
		$aResult = Util::getDefaultArrayResult();
		$pedidos = $request->input('pedido'); // los datos del pedidos, productos a comprar
		$id_producto = $request->input('id_producto');
		$id_tipo_envio = $request->input('id_tipo_envio');
		$precio_envio_db = $request->input('precio_envio_db');
		if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$total_envio = 0;
			foreach ($pedidos as $pedido) {
				if ($pedido['id_producto'] == $id_producto) {
					$tipo_envio = TipoEnvio::find($id_tipo_envio);
					$pedidoProducto = PedidosProductos::find($pedido['id_pedido_producto']);
					$pedidoProducto->id_tipo_envio = $id_tipo_envio;
					$pedidoProducto->id_tipo = $tipo_envio->id_tipo;
					$pedidoProducto->precio_envio = $precio_envio_db;
					$pedidoProducto->nombre_envio = $tipo_envio->nombre;
					$pedidoProducto->empresa_envio = $tipo_envio->empresa;
					$pedidoProducto->save();
					$total_envio = $total_envio + $precio_envio_db;
				} else {
					$pedidoProducto = PedidosProductos::find($pedido['id_pedido_producto']);
					$total_envio = $total_envio + $pedidoProducto->precio_envio;
				}
			}
			$aResult['data'] = $total_envio;
		}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}
		return response()->json($aResult);
	}
	public function array_value_recursive($key, array $arr){
		$val = array();
		array_walk_recursive($arr, function($v, $k) use($key, &$val){
			if($k == $key) array_push($val, $v);
		});
		return count($val) > 1 ? $val : array_pop($val);
	}

	public function getSucursalEnvio(Request $request){
		$aResult = Util::getDefaultArrayResult();
		if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			$id_pedido = $request->input('id_pedido');
			$pedido = Cart::get_pedido($id_pedido);
			//traer sucursales que tengan todos esos productos, si no que muestre la fecha en la q estará en esa sucursal según la configuración general
			$sucursales = Note::select('id_nota as id','titulo','sumario', 'ciudad')
			->where('id_edicion',\config('appCustom.MOD_SUCURSALES_FILTER'))
			->where('habilitado',1)
			->orderBy('destacado','desc')
			->orderBy('orden','asc')
			->get()->toArray();
			//$aResult['data'] = $pedido['carrito'];
			
			$carrito =$pedido['carrito'];
			array_walk($sucursales, function(&$val,$key)use($carrito){
				$stock_sucursal = true;
				//busco en que sucursales hay stock de todo el carrito
				foreach($carrito as $idc){
					$data = SucursalesStock::select('stock')
					->where('id_sucursal', $val['id'])
					->where('stock', '>=', $idc['cantidad'])
					->where('id_codigo_stock', $idc['id_codigo_stock'])
					->first();
					if(!$data){
						$stock_sucursal = false;
					}
				}
				if($stock_sucursal){
					$val['disponible'] = 1;
					$val['name'] = $val['sumario'].' - Disponible en sucursal';
					$val['fecha'] = array(
						'fecha' => Carbon::now()->format('Y/m/d h:i:s'),
						'dia' => Carbon::now()->format('d/m/Y'),
						'hora' => Carbon::now()->format('h')
					);
				}else{
					$val['disponible'] = 0;
					$dias_retiro = FeUtilController::getDiasRetiroSucursal();
					if($dias_retiro){
						$val['fecha'] = array(
							'fecha' => Carbon::now()->addDays($dias_retiro)->format('Y/m/d h:i:s'),
							'dia' => Carbon::now()->addDays($dias_retiro)->format('d/m/Y'),
							'hora' => Carbon::now()->addDays($dias_retiro)->format('h')
						);
						$val['name'] = $val['sumario'].' - Disponible a partir del '.$val['fecha']['dia'].' a las '.$val['fecha']['hora'].'hs.';
					}else{
						$val = array();
					}
				}
				$val['cost'] = 0;
			});
			$aResult['data'] = $sucursales;
		}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}	
		return response()->json($aResult);
	}

	public function consultaCostoEnvio(Request $request){
		$aResult = Util::getDefaultArrayResult();
		$andreani_datos = array(
			'cliente' 	=> \config('appCustom.ANDREANI_CLIENTE'), 
			'usuario' 	=> \config('appCustom.ANDREANI_USUARIO'),
			'pass' 		=> \config('appCustom.ANDREANI_PASS'),
			'ambiente' 	=> \config('appCustom.ANDREANI_AMBIENTE')
		);
		$id = $request->input('id');
		$codigo_postal = $request->input('codigo_postal');
		// $subtotal = $request->input('subtotal');
		if ($this->user->hasAccess($this->resource . '.view') && $this->filterNote) {
			// $cp = PedidosDirecciones::find($id);
			$item = Productos::find($id);
			$precio = PreciosProductos::where('id_producto','=',$id)->where('id_moneda','=',1)->first();
			$respuesta = array();
			if ($item->alto <= 70 && $item->ancho <= 70 and $item->largo <= 70 and $item->paso <= 25000 ) {								
				$params = array(
					"dimensions"	=> $item->alto."x".$item->ancho."x".$item->largo.",".$item->peso,
					"zip_code" 		=> $codigo_postal,
					"item_price"	=> $precio->precio_venta
				);
				$response = MP::get('/shipping_options',$params);
				if($response){
					$shipping_options = $response['response']['options'];
					foreach($shipping_options as $shipping_option) {
						$shipping_method_id = $shipping_option['shipping_method_id'];
						$name = $shipping_option['name'];
						$shipping_speed = $shipping_option['estimated_delivery_time']['shipping'];
						$estimated_delivery = $shipping_speed < 24 ? (1).' dia' : ceil($shipping_speed / 24).' d&iacute;as'; //from departure, estimated delivery time
						$cost = $shipping_option['cost'];
						$tipo = TipoEnvio::select('id_tipo_envio')->where('id_tipo',$shipping_method_id)->first();
						if($tipo){
							$id_tipo_envio = $tipo->id_tipo_envio;
						}else{
							$tipo_envio = new TipoEnvio;
							$tipo_envio->id_tipo = $shipping_method_id;
							$tipo_envio->nombre = $name;
							$tipo_envio->empresa = 'MercadoE';
							$tipo_envio->save();
							$id_tipo_envio = $tipo_envio->id_tipo_envio;
						}
						$data = array(
							'id' => $shipping_method_id,
							'name' => $name,
							'id_tipo_envio' => $id_tipo_envio,
							'cost' => $cost,
							'total' => Util::getPrecioFormat($precio->precio_venta),
							'empresa' => 'Mercado Envíos'
						);
						array_push($respuesta,$data);
					}
				}
			}

			// Calculos de precios de envios para Andreani
			$volumen = $item->alto*$item->ancho*$item->largo;
			$tipo_envio = TipoEnvio::select('id_tipo_envio','id_tipo','nombre')->where('empresa','=','Andreani')->get();

			if ($tipo_envio) {
				foreach ($tipo_envio as $tipo) {
					// Los siguientes datos son de prueba, para la implementación en un entorno productivo deberán reemplazarse por los verdaderos					    
				    $cotizar = new CotizarEnvio();
				    $cotizar->setCodigoDeCliente($andreani_datos['cliente']);
				    $cotizar->setNumeroDeContrato($tipo->id_tipo);
				    $cotizar->setCodigoPostal($codigo_postal);
				    $cotizar->setPeso($item->peso);
				    $cotizar->setVolumen($volumen);
				    $cotizar->setValorDeclarado($precio->precio_venta);

				    $andreani = new Andreani($andreani_datos['usuario'],$andreani_datos['pass'],$andreani_datos['ambiente']);
				    $response = $andreani->call($cotizar);
				    if($response->isValid()){
				    	$mensaje = $response->getMessage();
				    	$data = array(
							'id' => $tipo->id_tipo,
							'name' => $tipo->nombre,
							'id_tipo_envio' => $tipo->id_tipo_envio,
							'cost' => $mensaje->CotizarEnvioResult->Tarifa,
							'total' => Util::getPrecioFormat($precio->precio_venta),
							'respuesta' => $mensaje,
							'empresa' => 'Andreani'
						);
						array_push($respuesta,$data);					        
				    }
				}
			}
			$aResult['data'] = $respuesta;
		}else {
			$aResult['status'] = 1;
			$aResult['msg'] = \config('appCustom.messages.unauthorized');
		}	
		return response()->json($aResult);			
	}

	/*public function andreani(Request $request)
	{
		$aResult = Util::getDefaultArrayResult();
		$envio = Cart::altaEnvio();
		$aResult['data'] = $envio;
		return response()->json($aResult);	
	}	*/		

}
