<?php
namespace App\Http\Controllers\Fe;

use App\AppCustom\Util;
use App\AppCustom\Models\Note;
use App\AppCustom\Models\NoteLanguage;
use App\AppCustom\Models\Image;
use App\AppCustom\Models\NoteStatistic;
use App\AppCustom\Models\ProductStatistic;
use App\AppCustom\Models\PreciosProductos;
use App\AppCustom\Models\CodigoStock;
use App\AppCustom\Models\Talles;
use App\AppCustom\Models\ConfGeneral;

class FeUtilController
{	
	static function getImages($id, $cantidad, $resource) {
	
		$aOItems = Image::select('imagen','imagen_file','epigrafe','id_color')
		->where('resource', $resource)
		->where('resource_id', $id)
		->where('habilitado', 1)
		->orderBy('destacada','desc');
		if($cantidad == 'color'){
			$aOItems = $aOItems->groupBy('id_color');
		}elseif($cantidad != 'all'){
			$aOItems = $aOItems->limit($cantidad);
		}
		$aOItems = $aOItems->get()->toArray();
		array_walk($aOItems, function(&$val,$key)use($resource){
			if(!file_exists(\config('appCustom.UPLOADS_BE').$resource . '/' . $val['imagen_file'])){
				$val['imagen_file'] = 'producto.jpg';
			}
		});
		
        return $aOItems;
	}
	static function getImagesByColor($id, $cantidad, $resource, $id_color) {
		$aOItems = Image::select('imagen','imagen_file','epigrafe','id_color')
		->where('resource', $resource)
		->where('resource_id', $id)
		->where('id_color',$id_color)
		->where('habilitado', 1)
		->orderBy('destacada','desc');
		if($cantidad == 'color'){
			$aOItems = $aOItems->groupBy('id_color');
		}elseif($cantidad != 'all'){
			$aOItems = $aOItems->limit($cantidad);
		}
		$aOItems = $aOItems->get()->toArray();
		array_walk($aOItems, function(&$val,$key)use($resource){
			if(!file_exists(\config('appCustom.UPLOADS_BE'). $resource . '/' . $val['imagen_file'])){
				$val['file_original'] = $val['imagen_file'];
				$val['imagen_file'] = 'producto.jpg';
			}
		});
		
        return $aOItems;
	}
	static function getTalle($id){
		$talle = Talles::find($id);
		return $talle;
	}
	static function getLenguage($id, $id_idioma) {
		if($id_idioma>0){
			$lItem1 = NoteLanguage::select('id_nota','titulo','sumario','texto','keyword')
			->where('id_idioma',$id_idioma)
			->where('id_nota',$id)
			->where('habilitado', 1)
			->first();
		}
		$aItems = Note::find($id);
		
		$aItems->titulo = ($id_idioma>0 && $lItem1?$lItem1->titulo:$aItems->titulo);
		$aItems->sumario = ($id_idioma>0 && $lItem1?$lItem1->sumario:$aItems->sumario);
		$aItems->texto = ($id_idioma>0 && $lItem1?$lItem1->texto:$aItems->texto);
		$aItems->keyword = ($id_idioma>0 && $lItem1?$lItem1->keyword:$aItems->keyword);
		
		return $aItems;
	}
    static function newVisitor($id, $title){
		$statistic = NoteStatistic::select('id')->where('id_nota',$id)->first();
		if($statistic){
			$statistic_new = NoteStatistic::find($statistic ->id);
			$statistic_new->visitas++;
		}else{
			$statistic_new = new NoteStatistic;
			$statistic_new->id_nota = $id;
			$statistic_new->titulo = $title;
			$statistic_new->visitas = 1;
		}
		return $statistic_new->save();
	}
	static function newVisitorProduct($id, $title){
		$statistic = ProductStatistic::select('id')->where('id_producto',$id)->first();
		if($statistic){
			$statistic_new = ProductStatistic::find($statistic ->id);
			$statistic_new->visitas++;
		}else{
			$statistic_new = new ProductStatistic;
			$statistic_new->id_producto = $id;
			$statistic_new->titulo = $title;
			$statistic_new->visitas = 1;
		}
		return $statistic_new->save();
	}
	static function getPrecios($id, $id_moneda) {
		$precio = PreciosProductos::
		select('precio_venta','precio_lista','descuento')
		->where('id_producto', $id)
		->where('id_moneda', $id_moneda)
		->first();
		if($precio){
			//si tiene descuento, va sobre el precio de lista
			if($precio->descuento>0 && $precio->precio_lista>0){
				$precio->precio_db = ($precio->precio_lista-$precio->descuento);
				$precio->oferta = round(($precio->descuento*100)/$precio->precio_lista);
			}else{
				$precio->precio_db = $precio->precio_venta;
			}
			$precio->precio_lista = Util::getPrecioFormat($precio->precio_lista);
			$precio->precio = Util::getPrecioFormat($precio->precio_db);
		}else{
			$precio = false;
		}
		return $precio;
	}
	
	static function getColorTalles($id, $id_color = 0) {
		$codigo = CodigoStock::
		select(\DB::raw('id_color, SUM(stock) as stock_total, codigo'))
		->where('id_producto', $id)
		->havingRaw('SUM(stock) > 0')
		->orderBy('id_color');
		if($id_color){
			$codigo = $codigo->where('id_color', $id_color);
		}
		$codigo = $codigo->groupBy('id_color')->get()->toArray();
		array_walk($codigo, function(&$val,$key)use($id){
			$aOItems = FeUtilController::getImages($val['id_color'], 'color', 'colores');
			if($aOItems){
				$val['foto'] = $aOItems;
			}
			//talles
			$talles = CodigoStock::
			select('inv_producto_codigo_stock.id_talle','inv_producto_codigo_stock.stock','inv_producto_codigo_stock.codigo','conf_talles.nombre')
			->leftJoin('conf_talles','conf_talles.id','=','inv_producto_codigo_stock.id_talle')
			->where('inv_producto_codigo_stock.id_color', $val['id_color'])
			->where('inv_producto_codigo_stock.id_producto', $id)
			->where('conf_talles.habilitado', 1)
			->where('inv_producto_codigo_stock.stock','>', 0)
			->orderBy('conf_talles.nombre','asc')
			->get()->toArray();
			if($talles){
				//buscar equivalencias
				/*array_walk($talles, function(&$val,$key){
					
				});*/
				FeUtilController::array_sort_by($talles, 'nombre');
				$val['talles'] = $talles;
			}
		});
		
		return $codigo;
	}
	static function array_sort_by(&$arrIni, $col, $order = SORT_ASC)
	{
		$arrAux = array();
		foreach ($arrIni as $key=> $row)
		{
			$arrAux[$key] = is_object($row) ? $arrAux[$key] = $row->$col : $row[$col];
			$arrAux[$key] = strtolower($arrAux[$key]);
		}
		array_multisort($arrAux, $order, $arrIni);
	}
	static function getStockColor($id, $id_color='') {
		$codigo = CodigoStock::
		select('id_color','id_talle','codigo','stock')
		->where('id_producto', $id)
		->orderBy('id_color');
		if($id_color!=''){
			$codigo = $codigo->where('id_color', $id_color);
		}
		$codigo = $codigo->get()->toArray();
		
		return $codigo;
	}
	static function getStockColorTalle($id, $id_color='', $id_talle='') {
		$codigo = CodigoStock::
		select('id_color','id_talle','codigo','stock')
		->where('id_producto', $id)
		->orderBy('id_color');
		if($id_color!=''){
			$codigo = $codigo->where('id_color', $id_color);
		}
		if($id_talle!=''){
			$codigo = $codigo->where('id_talle', $id_talle);
		}
		$codigo = $codigo->get()->toArray();
		
		return $codigo;
	}

	static function getPrecioEnvioGratis(){
		$precio = ConfGeneral::find(1);
		if($precio->habilitado==1){
			return $precio->valor;
		}else{
			return null;
		}
	}
	static function getDiasRetiroSucursal(){
		$precio = ConfGeneral::find(2);
		if($precio->habilitado==1){
			return $precio->valor;
		}else{
			return null;
		}
	}
	
	static function enviarConfirmEmail($cliente) {
		
		$params = 'mailConfirmed=yes';
		$params .= '&i='.$cliente->id;
		$params .= '&k=' . \base64_encode($cliente->confirm_token);
		
		$confirmLink = env('FE_URL');
		$confirmLink .= 'mailconfirmed?' . $params;
	
		try {
			\Mail::send('email.confirmation', ['cliente' => $cliente, 'confirmLink' => $confirmLink], function($message) use ($cliente){
				$message
					->to($cliente->mail)
					->subject(\config('appCustom.clientName') . '. Confirmación de Registro');
			});
		} catch (\Exception $e) {
			\Log::error($e->getMessage());
			return $e->getMessage();
		}
		
		return 1;
		
	}
	
	static function enviarPassForgotEmail($cliente) {
		
		$params = 'passRestore=yes';
		$params .= '&i='.$cliente->id;
		$params .= '&k=' . \base64_encode($cliente->forgot_token);
		
		$confirmLink = env('FE_URL');
		$confirmLink .= 'reset_password?' . $params;
	
		try {
			\Mail::send('email.passwordForgot', ['user' => $cliente->nombre, 'link' => $confirmLink], function($message) use ($cliente){
				$message
					->to($cliente->mail)
					->subject(\config('appCustom.clientName') . '. Recuperar contraseña');
			});
		} catch (\Exception $e) {
			\Log::error($e->getMessage());
			return $e->getMessage();
		}
		
		return 1;
		
	}
	
	
}
