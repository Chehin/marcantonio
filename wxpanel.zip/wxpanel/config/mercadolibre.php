<?php

return [
	'app_id'     => env('ML_APP_ID', ''),
	'app_secret' => env('ML_APP_SECRET', ''),
	'app_redirect' => env('ML_APP_REDIRECT'),
	'app_sideid' => env('ML_APP_SITEID')
];